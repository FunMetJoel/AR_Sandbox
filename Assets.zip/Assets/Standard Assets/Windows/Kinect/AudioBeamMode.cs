using RootSystem = System;
using System.Linq;
using System.Collections.Generic;
namespace Windows.Kinect
{
    //
    // Windows.Kinect.AudioBeamMode
    //
    public enum AudioBeamMode : int
    {
        Automatic                                =0,
        Manual                                   =1,
    }

}
